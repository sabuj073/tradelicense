<div class="page_logo">
    <img src="assets/img/logo.png" alt="">
</div>
