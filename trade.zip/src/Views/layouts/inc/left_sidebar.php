<nav id="sidebarMenu" class="col-md-2 col-lg-2 d-md-block p-3 sidebar collapse primary_bg">
    <div class="image_logo  ">
        <div class="image_item">
            <img class="d-block w-100" src="assets/img/side/1.jpg">
        </div>

        <div class="image_item">
            <img class="d-block w-100" src="assets/img/side/3.png">
        </div>
        <div class="image_item">
            <img class="d-block w-100" src="assets/img/side/4.png">
        </div>
        <div class="image_item">
            <img class="d-block w-100" src="assets/img/side/1.jpg">
        </div>

        <div class="image_item">
            <img class="d-block w-100" src="assets/img/side/3.png">
        </div>
        <div class="image_item">
            <img class="d-block w-100" src="assets/img/side/4.png">
        </div>
    </div>
</nav>
