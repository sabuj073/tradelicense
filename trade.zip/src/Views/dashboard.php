<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h1>Welcome to your dashboard!</h1>
    <a href="/logout">Logout</a>
</body>
</html>
